

<script>
    $('.view-notigy a').on('click',function(){
        $('#notifymodal').modal('show');
    });
</script>
