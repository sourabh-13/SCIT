<!-- View Need Assistance Chat modal -->
<div class="modal fade" id="needModal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <section class="panel">
                <div class="modal-header"> 
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button> 
                    <a href="#" data-toggle="modal" data-dismiss="modal" data-target="#careCenterModel" class="close" style="padding-right:6px"> <i class="fa fa-arrow-left"></i></a>
                    <h4 class="modal-title" id="mySmallModalLabel"> Need Assistance </h4>
                </div>    
                <div class="panel-body ">
                    <div class="ass-chat-view-click cht-hgt cal_evnt_scroller" style="max-height:500px">
                   <!--  chat shown using ajax -->
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>


