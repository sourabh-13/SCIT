<!-- Modal -->
<div class="modal fade" id="incentivesModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Trips</h4>
            </div>
                <div class="incen-body">
                    <div class="view_incentive_details">
                    <!--  Data show using ajax  -->
                    </div>
                </div>

            <!-- <div class="modal-footer incen-foot">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
            </div> -->
            <div class="row"></div>
        </div>
    </div>
</div>

